public class Lista<T> {
    public Node<T> head;

    public Lista() {
        this.head = null;
    }

    public void insert(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    public T find(T target) {
        Node<T> current = head;
        while (current != null) {
            if (current.data.equals(target)) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    public boolean delete(T target) {
        Node<T> current = head;
        while (current != null) {
            if (current.data.equals(target)) {
                if (current.prev != null) {
                    current.prev.next = current.next;
                } else {
                    head = current.next;
                }
                if (current.next != null) {
                    current.next.prev = current.prev;
                }
                return true;
            }
            current = current.next;
        }
        return false;
    }
}