public class Tarea {
    public String descripcion;
    public String departamento;
    public int urgencia; // 1 = Alta (Urgente), 2 = Media (Regular), 3 = Baja (Lista)

    public Tarea(String descripcion, String departamento, int urgencia) {
        this.descripcion = descripcion;
        this.departamento = departamento;
        this.urgencia = urgencia;
    }

    public int getUrgencia() {
        return urgencia;
    }

    public String getDepartamento() {
        return departamento;
    }

    @Override
    public String toString() {
        String nivel = (urgencia == 1) ? "URGENTE" : (urgencia == 2) ? "REGULAR" : "NORMAL";
        return "[" + nivel + "] Depto: " + departamento + " | Tarea: " + descripcion;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Tarea otraTarea = (Tarea) obj;
        return this.descripcion.equalsIgnoreCase(otraTarea.descripcion);
    }
}