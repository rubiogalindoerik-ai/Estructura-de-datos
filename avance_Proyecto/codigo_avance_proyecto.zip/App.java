import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        Pila<Tarea> urgencias = new Pila<>();
        Cola<Tarea> programadas = new Cola<>();
        Lista<Tarea> porDepartamento = new Lista<>();

        int op, opc;
        do {
            System.out.println("\n-------- MENU HOSPITAL GENERAL --------");
            System.out.println("1. Tareas Urgentes (Pila)");
            System.out.println("2. Tareas Programadas (Cola)");
            System.out.println("3. Tareas por Departamento (Lista)");
            System.out.println("4. Ver todas las tareas pendientes (Ordenadas)");
            System.out.println("5. Salir");
            System.out.println("Introduce una opcion: ");
            op = scan.nextInt();
            scan.nextLine();
            switch (op) {
                case 1:
                    do {
                        System.out.println("\n--- TAREAS URGENTES (Pila) ---");
                        System.out.println("1. Agregar tarea (Push)");
                        System.out.println("2. Atender tarea más reciente (Pop)");
                        System.out.println("3. Ver próxima urgencia (Peek)");
                        System.out.println("4. Volver");
                        opc = scan.nextInt();
                        scan.nextLine();
                        if (opc == 1) {
                            System.out.println("Descripción de la urgencia: ");
                            String desc = scan.nextLine();
                            System.out.println("Departamento: ");
                            String depto = scan.nextLine();
                            urgencias.push(new Tarea(desc, depto, 1));
                        } else if (opc == 2) {
                            Tarea t = urgencias.pop();
                            if (t != null) System.out.println("Atendiendo: " + t);
                        } else if (opc == 3) {
                            Tarea t = urgencias.peek();
                            if (t != null) System.out.println("Siguiente en pila: " + t);
                        }
                    } while (opc != 4);
                    break;
                case 2:
                    do {
                        System.out.println("\n--- TAREAS PROGRAMADAS (Cola) ---");
                        System.out.println("1. Agregar tarea (Enqueue)");
                        System.out.println("2. Atender tarea más antigua (Dequeue)");
                        System.out.println("3. Ver primera en fila (Front)");
                        System.out.println("4. Volver");
                        opc = scan.nextInt();
                        scan.nextLine();
                        if (opc == 1) {
                            System.out.println("Descripción de la tarea: ");
                            String desc = scan.nextLine();
                            System.out.println("Departamento: ");
                            String depto = scan.nextLine();
                            programadas.enqueue(new Tarea(desc, depto, 2));
                        } else if (opc == 2) {
                            Tarea t = programadas.dequeue();
                            if (t != null) System.out.println("Atendiendo: " + t);
                        } else if (opc == 3) {
                            Tarea t = programadas.front();
                            if (t != null) System.out.println("Primera en fila: " + t);
                        }
                    } while (opc != 4);
                    break;
                case 3:
                    do {
                        System.out.println("\n--- TAREAS POR DEPARTAMENTO (Lista) ---");
                        System.out.println("1. Agregar tarea (Insert)");
                        System.out.println("2. Buscar tarea por descripción (Find)");
                        System.out.println("3. Eliminar tarea (Delete)");
                        System.out.println("4. Mostrar todas las tareas de esta lista");
                        System.out.println("5. Volver");
                        opc = scan.nextInt();
                        scan.nextLine();
                        if (opc == 1) {
                            System.out.println("Descripción de la tarea: ");
                            String desc = scan.nextLine();
                            System.out.println("Departamento (Ej. Cardiología, Urgencias): ");
                            String depto = scan.nextLine();
                            porDepartamento.insert(new Tarea(desc, depto, 3));
                            System.out.println("Tarea registrada en el sistema.");
                        } else if (opc == 2) {
                            System.out.println("Ingresa la descripción exacta de la tarea a buscar: ");
                            String desc = scan.nextLine();
                            Tarea buscar = new Tarea(desc, "", 3);
                            Tarea encontrada = porDepartamento.find(buscar);
                            if (encontrada != null) {
                                System.out.println("Tarea encontrada -> " + encontrada);
                            } else {
                                System.out.println("No se encontró ninguna tarea con esa descripción.");
                            }
                        } else if (opc == 3) {
                            System.out.println("Ingresa la descripción exacta de la tarea a eliminar: ");
                            String desc = scan.nextLine();
                            Tarea eliminar = new Tarea(desc, "", 3);
                            boolean exito = porDepartamento.delete(eliminar);
                            if (exito) {
                                System.out.println("Tarea eliminada correctamente.");
                            } else {
                                System.out.println("No se pudo eliminar. Tarea no encontrada.");
                            }
                        } else if (opc == 4) {
                            System.out.println("\n--- Lista de Tareas por Departamento ---");
                            Node<Tarea> actualLista = porDepartamento.head;
                            if (actualLista == null) {
                                System.out.println("La lista está vacía.");
                            } else {
                                while (actualLista != null) {
                                    System.out.println(actualLista.data);
                                    actualLista = actualLista.next;
                                }
                            }
                        } else if (opc == 5) {
                            System.out.println("Volviendo al menú principal...");
                        } else {
                            System.out.println("Opción no válida.");
                        }
                    } while (opc != 5);
                    break;
                case 4:
                    System.out.println("\n--- TODAS LAS TAREAS PENDIENTES ---");
                    ArrayList<Tarea> todas = new ArrayList<>();
                    Node<Tarea> actualPila = urgencias.top;
                    while(actualPila != null) { todas.add(actualPila.data); actualPila = actualPila.next; }
                    Node<Tarea> actualCola = programadas.front;
                    while(actualCola != null) { todas.add(actualCola.data); actualCola = actualCola.next; }
                    Node<Tarea> actualLista = porDepartamento.head;
                    while(actualLista != null) { todas.add(actualLista.data); actualLista = actualLista.next; }
                    todas.sort(new java.util.Comparator<Tarea>() {
                        @Override
                        public int compare(Tarea t1, Tarea t2) {
                            int urgenciaCmp = Integer.compare(t1.getUrgencia(), t2.getUrgencia());
                            if (urgenciaCmp != 0) {
                                return urgenciaCmp;
                            }
                            return t1.getDepartamento().compareToIgnoreCase(t2.getDepartamento());
                        }
                    });
                    for (Tarea t : todas) {
                        System.out.println(t);
                    }
                    break;
            }
        } while (op != 5);
        scan.close();
    }
}