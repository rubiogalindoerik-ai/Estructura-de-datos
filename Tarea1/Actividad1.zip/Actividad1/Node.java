public class Node<T> {
  T data;
  Node<T> next;
  Node<T> prev;

  public Node(T data) {
    this.data = data;
    this.next = null;
    this.prev = null;
  }

  public String toString() {
    return data != null ? data.toString() : "null";
  }
}
