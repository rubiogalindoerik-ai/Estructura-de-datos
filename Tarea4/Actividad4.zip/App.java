public class App {
    public static void main(String[] args) {
        Arbolbinario arbol = new Arbolbinario();

        Empleado[] empleados = {
            new Empleado(1, "Erick"),
            new Empleado(2, "Luis"),
            new Empleado(3, "Sofia"),
            new Empleado(4, "Ana"),
            new Empleado(5, "Carlos"),
            new Empleado(6, "Maria"),
            new Empleado(7, "Pedro")
        };

        System.out.println("--- Insertando empleados en el árbol ---");
        for (Empleado emp : empleados) {
            arbol.insertar(emp);
        }

        System.out.println("\n--- Probando los recorridos ---");
        arbol.mostrarInOrden();
        arbol.mostrarPreOrden();
        arbol.mostrarPostOrden();

        System.out.println("--- Búsqueda de Empleados ---");
        Empleado buscado = arbol.buscar(1);
        System.out.println("Buscando ID 1: " + (buscado != null ? "Encontrado -> " + buscado.nombre : "No encontrado."));
        
        buscado = arbol.buscar(2);
        System.out.println("Buscando ID 2: " + (buscado != null ? "Encontrado -> " + buscado.nombre : "No encontrado."));

        System.out.println("\n--- Eliminación de Empleados ---");
        System.out.println("Eliminando ID 3...");
        arbol.eliminar(3);
        arbol.mostrarInOrden();
    }
}