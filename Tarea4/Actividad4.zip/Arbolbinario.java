public class Arbolbinario {
    private Nodo raiz;

    public Arbolbinario() {
        this.raiz = null;
    }

    private Nodo insertarRecursivo(Nodo actual, Empleado empleado) {
        if (actual == null) {
            return new Nodo(empleado);
        }
        if (empleado.id < actual.empleado.id) {
            actual.left = insertarRecursivo(actual.left, empleado);
        } else if (empleado.id > actual.empleado.id) {
            actual.right = insertarRecursivo(actual.right, empleado);
        }
        return actual;
    }

    public void insertar(Empleado empleado) {
        raiz = insertarRecursivo(raiz, empleado);
    }

    private Empleado buscarRecursivo(Nodo actual, int id) {
        if (actual == null || actual.empleado.id == id) {
            return actual != null ? actual.empleado : null;
        }
        if (actual.empleado.id > id) {
            return buscarRecursivo(actual.left, id);
        }
        return buscarRecursivo(actual.right, id);
    }

    public Empleado buscar(int id) {
        return buscarRecursivo(raiz, id);
    }

    private Nodo eliminarRecursivo(Nodo actual, int id) {
        if (actual == null) return actual;

        if (id < actual.empleado.id) {
            actual.left = eliminarRecursivo(actual.left, id);
        } else if (id > actual.empleado.id) {
            actual.right = eliminarRecursivo(actual.right, id);
        } else {
            if (actual.left == null) return actual.right;
            else if (actual.right == null) return actual.left;

            actual.empleado = valorMinimo(actual.right);
            actual.right = eliminarRecursivo(actual.right, actual.empleado.id);
        }
        return actual;
    }

    public void eliminar(int id) {
        raiz = eliminarRecursivo(raiz, id);
    }

    private Empleado valorMinimo(Nodo actual) {
        Empleado min = actual.empleado;
        while (actual.left != null) {
            min = actual.left.empleado;
            actual = actual.left;
        }
        return min;
    }

    public void inOrdenRecursivo(Nodo nodo) {
        if (nodo == null) return;
        inOrdenRecursivo(nodo.left);
        System.out.print(nodo.empleado + " | ");
        inOrdenRecursivo(nodo.right);
    }

    public void preOrdenRecursivo(Nodo nodo) {
        if (nodo == null) return;
        System.out.print(nodo.empleado + " | ");
        preOrdenRecursivo(nodo.left);
        preOrdenRecursivo(nodo.right);
    }

    public void postOrdenRecursivo(Nodo nodo) {
        if (nodo == null) return;
        postOrdenRecursivo(nodo.left);
        postOrdenRecursivo(nodo.right);
        System.out.print(nodo.empleado + " | ");
    }

    public void mostrarInOrden() {
        System.out.println("InOrden:");
        inOrdenRecursivo(raiz);
        System.out.println("\n");
    }
    
    public void mostrarPreOrden() {
        System.out.println("PreOrden:");
        preOrdenRecursivo(raiz);
        System.out.println("\n");
    }

    public void mostrarPostOrden() {
        System.out.println("PostOrden:");
        postOrdenRecursivo(raiz);
        System.out.println("\n");
    }
}