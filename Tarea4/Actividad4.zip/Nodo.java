public class Nodo {
    Empleado empleado;
    Nodo left;
    Nodo right;

    public Nodo(Empleado empleado) {
        this.empleado = empleado;
        this.left = null;
        this.right = null;
    }
}
