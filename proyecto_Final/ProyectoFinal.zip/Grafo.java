import java.util.*;

public class Grafo {

    private Map<String, List<String>> listaAdyacencia = new HashMap<>();

    public void agregarVertice(String vertice) {
        listaAdyacencia.putIfAbsent(vertice, new ArrayList<>());
    }

    public void agregarArista(String origen, String destino) {
        agregarVertice(origen);
        agregarVertice(destino);
        listaAdyacencia.get(origen).add(destino);
    }

    // Consultar las dependencias directas de una tarea
    public String obtenerInfoDependencias(String idTarea) {
        List<String> prerequisitos = new ArrayList<>();
        
        // BQue tarea debe hacerse antes
        for (String vertice : listaAdyacencia.keySet()) {
            if (listaAdyacencia.get(vertice).contains(idTarea)) {
                prerequisitos.add(vertice);
            }
        }
        
        // Que tarea se desbloquea despues
        List<String> siguientes = listaAdyacencia.get(idTarea);
        
        String info = "";
        if (!prerequisitos.isEmpty()) {
            info += "  >> [REQUIERE PREVIO: " + String.join(", ", prerequisitos) + "]";
        }
        if (siguientes != null && !siguientes.isEmpty()) {
            info += "  >> [HABILITA A: " + String.join(", ", siguientes) + "]";
        }
        
        return info;
    }

    // Obtener la lista que se hizo antes de prerequisitos
    public String[] obtenerPrerequisitosArreglo(String idTarea) {
        // Contar cuántos prerrequisitos hay para darle tamaño al arreglo
        int contador = 0;
        for (String vertice : listaAdyacencia.keySet()) {
            if (listaAdyacencia.get(vertice).contains(idTarea)) {
                contador++;
            }
        }
        
        // Crear el arreglo estático con el tamaño exacto
        String[] prerequisitos = new String[contador];
        int indice = 0;
        
        // Llenar el arreglo el arreglo
        for (String vertice : listaAdyacencia.keySet()) {
            if (listaAdyacencia.get(vertice).contains(idTarea)) {
                prerequisitos[indice] = vertice;
                indice++;
            }
        }
        return prerequisitos;
    }

    // 
    public String obtenerRutaDfsGUI(String inicio) {
        Set<String> visitados = new HashSet<>();
        StringBuilder resultado = new StringBuilder();
        dfsAcumulado(inicio, visitados, resultado);
        return resultado.toString();
    }

    private void dfsAcumulado(String actual, Set<String> visitados, StringBuilder sb) {
        visitados.add(actual);
        sb.append(" -> ").append(actual).append("\n");
        
        for(String vecino : listaAdyacencia.get(actual)) {
            if (!visitados.contains(vecino)) {
               dfsAcumulado(vecino, visitados, sb);
            } 
        }
    }
}