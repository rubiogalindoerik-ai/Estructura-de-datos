public class Empleado {
    public int idMedico;
    public String nombre;
    public String departamento;

    public Empleado(int idMedico, String nombre, String departamento) {
        this.idMedico = idMedico;
        this.nombre = nombre;
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "ID: " + idMedico + " | Nombre: " + nombre + " | Depto: " + departamento;
    }
}