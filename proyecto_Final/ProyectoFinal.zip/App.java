import javax.swing.*;
import java.awt.*;

public class App extends JFrame {
    private JTextArea areaResultado;

    private PriorityQueue<Tarea> colaTareas;
    private SimpleHashTable<String, Tarea> directorioTareas;
    private Arbolbinario arbolMedicos;
    private Grafo grafoHospital;

    // Contador para los IDs
    private int contadorId = 6;
    
    // AArreglo para ver que tareas fueron terminadas
    private String[] tareasTerminadas;
    private int terminadasCount;

    public App() {
        colaTareas = new PriorityQueue<>();
        directorioTareas = new SimpleHashTable<>(20);
        arbolMedicos = new Arbolbinario();
        grafoHospital = new Grafo();
        
        tareasTerminadas = new String[500]; 
        terminadasCount = 0;

        // Empleados de prueba
        arbolMedicos.insertar(new Empleado(105, "Dr. Perez", "Urgencias"));
        arbolMedicos.insertar(new Empleado(101, "Dra. Gomez", "Cardiologia"));
        arbolMedicos.insertar(new Empleado(110, "Enf. Martinez", "Pediatria"));

        // Tareas de prueba
        Tarea t1 = new Tarea("T-001", "Paciente con paro cardíaco", "Urgencias", 1, 60);
        colaTareas.enqueue(t1, t1.urgencia);
        directorioTareas.put(t1.id, t1);

        Tarea t2 = new Tarea("T-002", "Revisión de rutina", "Consultorio 3", 3, 15);
        colaTareas.enqueue(t2, t2.urgencia);
        directorioTareas.put(t2.id, t2);

        Tarea t3 = new Tarea("T-003", "Curación de herida leve", "Enfermería", 2, 20);
        colaTareas.enqueue(t3, t3.urgencia);
        directorioTareas.put(t3.id, t3);

        Tarea t4 = new Tarea("T-004", "Cirugía de apéndice", "Quirófano", 1, 120);
        colaTareas.enqueue(t4, t4.urgencia);
        directorioTareas.put(t4.id, t4);

        Tarea t5 = new Tarea("T-005", "Traslado a Rayos X", "Radiología", 3, 10);
        colaTareas.enqueue(t5, t5.urgencia);
        directorioTareas.put(t5.id, t5);

        // Dependecia de prueba
        grafoHospital.agregarArista("T-005", "T-004"); 
        grafoHospital.agregarArista("T-002", "T-003");

        // Interfaz
        setTitle("Sistema del Hospital General");
        setSize(700, 450); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        JPanel panelBotones = new JPanel(new GridLayout(7, 1, 5, 10)); 
        
        JButton btnAgregar = new JButton("Agregar Tarea");
        JButton btnAtender = new JButton("Atender Siguiente");
        JButton btnBuscar = new JButton("Buscar Tarea por ID");
        JButton btnMostrar = new JButton("Mostrar Todas"); 
        JButton btnVincular = new JButton("Crear Dependencia (Grafo)");
        JButton btnCalcular = new JButton("Calcular Tiempo Total");
        JButton btnPersonal = new JButton("Mostrar Personal");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnAtender);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnMostrar);
        panelBotones.add(btnVincular);
        panelBotones.add(btnCalcular);
        panelBotones.add(btnPersonal);

        panelIzquierdo.add(panelBotones, BorderLayout.NORTH);
        panelPrincipal.add(panelIzquierdo, BorderLayout.WEST);

        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("Arial", Font.PLAIN, 14));
        areaResultado.setText("Bienvenido al sistema del hospital.\nSeleccione una opción del menú izquierdo.");
        panelPrincipal.add(new JScrollPane(areaResultado), BorderLayout.CENTER);

        add(panelPrincipal);

        // Botones

        // Agregar Tarea
        btnAgregar.addActionListener(e -> {
            JTextField txtDesc = new JTextField();
            JTextField txtDepto = new JTextField();
            JTextField txtUrgencia = new JTextField("1");
            JTextField txtTiempo = new JTextField("30");

            Object[] formulario = {
                "Descripción de la tarea:", txtDesc,
                "Departamento:", txtDepto,
                "Urgencia (1=Alta, 2=Media, 3=Baja):", txtUrgencia,
                "Tiempo Estimado (minutos):", txtTiempo
            };

            int opcion = JOptionPane.showConfirmDialog(App.this, formulario, "Registrar Nueva Tarea", JOptionPane.OK_CANCEL_OPTION);
            
            if (opcion == JOptionPane.OK_OPTION) {
                try {
                    String desc = txtDesc.getText().trim();
                    String depto = txtDepto.getText().trim();
                    int urg = Integer.parseInt(txtUrgencia.getText().trim());
                    int tiempo = Integer.parseInt(txtTiempo.getText().trim());

                    if(desc.isEmpty() || depto.isEmpty()) {
                        areaResultado.setText("Error: Por favor llena todos los campos de texto.");
                        return;
                    }

                    String idAutomatico = String.format("T-%03d", contadorId);
                    contadorId++; 

                    Tarea nueva = new Tarea(idAutomatico, desc, depto, urg, tiempo);
                    colaTareas.enqueue(nueva, urg); 
                    directorioTareas.put(idAutomatico, nueva); 

                    areaResultado.setText("Tarea agregada exitosamente:\n" + nueva.toString());
                } catch (NumberFormatException ex) {
                    areaResultado.setText("Error: Urgencia y Tiempo deben ser NÚMEROS.");
                }
            }
        });

        // Atender Tarea 
        btnAtender.addActionListener(e -> {
            if (colaTareas.isEmpty()) {
                areaResultado.setText("No hay tareas pendientes por atender en la cola.");
                return;
            }

            Tarea[] tareasBloqueadas = new Tarea[colaTareas.size];
            int bloqueadasCount = 0;
            Tarea tareaAAtender = null;

            while (!colaTareas.isEmpty()) {
                Tarea actual = colaTareas.dequeue(); 
                
                String[] prerequisitos = grafoHospital.obtenerPrerequisitosArreglo(actual.id);
                boolean estaLista = true;
                
                for (int i = 0; i < prerequisitos.length; i++) {
                    String pre = prerequisitos[i];
                    boolean preTerminado = false;
                    
                    for (int j = 0; j < terminadasCount; j++) {
                        if (tareasTerminadas[j].equals(pre)) {
                            preTerminado = true;
                            break;
                        }
                    }
                    
                    if (!preTerminado) {
                        estaLista = false;
                        break; 
                    }
                }

                if (estaLista) {
                    tareaAAtender = actual; 
                    break; 
                } else {
                    tareasBloqueadas[bloqueadasCount] = actual;
                    bloqueadasCount++;
                }
            }

            for (int i = 0; i < bloqueadasCount; i++) {
                colaTareas.enqueue(tareasBloqueadas[i], tareasBloqueadas[i].urgencia); 
            }

            if (tareaAAtender != null) {
                tareasTerminadas[terminadasCount] = tareaAAtender.id;
                terminadasCount++;
                areaResultado.setText("Atendiendo la tarea (Prerrequisitos verificados):\n\n" + tareaAAtender.toString());
            } else {
                areaResultado.setText("¡ATENCIÓN!\nNo se puede atender la tarea más urgente en este momento.\n\n" +
                                      "Está bloqueada porque depende de un procedimiento que aún no se ha realizado.");
            }
        });

        // 3. Buscar por ID (Tabla Hash)
        btnBuscar.addActionListener(e -> {
            String idBusqueda = JOptionPane.showInputDialog(App.this, "Ingrese el ID de la tarea a buscar (Ej. T-001):");
            if(idBusqueda != null && !idBusqueda.trim().isEmpty()) {
                Tarea encontrada = directorioTareas.getV(idBusqueda.trim()); 
                if (encontrada != null) {
                    areaResultado.setText("Resultado de la Búsqueda:\n" + encontrada.toString());
                } else {
                    areaResultado.setText("La tarea con ID '" + idBusqueda + "' no existe en el sistema.");
                }
            }
        });

        // Mostrar Tareas
        btnMostrar.addActionListener(e -> {
            if (colaTareas.isEmpty()) {
                areaResultado.setText("No hay tareas pendientes en el sistema.");
            } else {
                StringBuilder texto = new StringBuilder("--- TODAS LAS TAREAS PENDIENTES ---\n");
                texto.append("(Ordenadas por mayor urgencia)\n\n");
                
                NodePrioridad<Tarea> actual = colaTareas.front;
                while(actual != null) {
                    texto.append(actual.data.toString());
                    String dependencias = grafoHospital.obtenerInfoDependencias(actual.data.id);
                    texto.append(dependencias).append("\n\n");
                    actual = actual.next;
                }
                areaResultado.setText(texto.toString());
            }
        });

        // Vincular Tareas
        btnVincular.addActionListener(e -> {
            JTextField txtPre = new JTextField();
            JTextField txtDep = new JTextField();

            Object[] formulario = {
                "ID de la Tarea Prerrequisito (Ej. T-005):", txtPre,
                "ID de la Tarea que depende de la anterior (Ej. T-004):", txtDep
            };

            int opcion = JOptionPane.showConfirmDialog(App.this, formulario, "Crear Dependencia de Tareas", JOptionPane.OK_CANCEL_OPTION);
            
            if (opcion == JOptionPane.OK_OPTION) {
                String idPre = txtPre.getText().trim();
                String idDep = txtDep.getText().trim();

                Tarea tPre = directorioTareas.getV(idPre);
                Tarea tDep = directorioTareas.getV(idDep);

                if (tPre == null || tDep == null) {
                    areaResultado.setText("Error: Uno o ambos IDs no existen en el sistema.");
                } else {
                    grafoHospital.agregarArista(idPre, idDep);
                    areaResultado.setText("Dependencia creada con éxito en el Grafo:\n\n" + 
                                          "Para poder iniciar [" + idDep + "] " + tDep.descripcion + "...\n" +
                                          "Primero debe completarse [" + idPre + "] " + tPre.descripcion);
                }
            }
        });

        // Calcular Tiempo Total
        btnCalcular.addActionListener(e -> {
            if (colaTareas.isEmpty()) {
                areaResultado.setText("La cola está vacía. No hay tiempos que calcular.");
            } else {
                Tarea[] arreglo = new Tarea[colaTareas.size];
                NodePrioridad<Tarea> actual = colaTareas.front;
                int i = 0;
                while(actual != null) {
                    arreglo[i] = actual.data;
                    actual = actual.next;
                    i++;
                }
                int total = AlgortimosBusqueda.calcularTiempoRecursivo(arreglo, 0, arreglo.length - 1);
                areaResultado.setText("Cálculo realizado (Divide y Vencerás).\nTiempo total estimado para todas las tareas: " + total + " minutos.");
            }
        });

        // Mostrar Personal
        btnPersonal.addActionListener(e -> {
            String resultado = arbolMedicos.obtenerInOrdenGUI();
            if (resultado.isEmpty()) {
                areaResultado.setText("No hay personal registrado en el árbol.");
            } else {
                areaResultado.setText("--- PERSONAL MÉDICO (Ordenado por ID) ---\n\n" + resultado);
            }
        });
    }

    public static void main(String[] args) {
        App ventana = new App();
        ventana.setVisible(true);
    }
}