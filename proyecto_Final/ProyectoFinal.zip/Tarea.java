public class Tarea {
    public String id;
    public String descripcion;
    public String departamento;
    public int urgencia;
    public int tiempoEstimado;

    public Tarea(String id, String descripcion, String departamento, int urgencia, int tiempoEstimado) {
        this.id = id;
        this.descripcion = descripcion;
        this.departamento = departamento;
        this.urgencia = urgencia;
        this.tiempoEstimado = tiempoEstimado;
    }

    @Override
    public String toString() {
        return "[" + id + "] " + descripcion + " (Depto: " + departamento + ") | Urgencia: " + urgencia + " | Tiempo: " + tiempoEstimado + " min";
    }
}