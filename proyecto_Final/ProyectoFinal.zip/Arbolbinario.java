public class Arbolbinario {
    public static class Nodo {
        Empleado data;
        Nodo left;
        Nodo right;

        public Nodo(Empleado data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private Nodo raiz;

    public Arbolbinario() {
        this.raiz = null;
    }

    private Nodo insertarRecursivo(Nodo actual, Empleado dato) {
        if (actual == null) {
            return new Nodo(dato);
        }
        if (dato.idMedico < actual.data.idMedico) {
            actual.left = insertarRecursivo(actual.left, dato);
        } else if (dato.idMedico >= actual.data.idMedico) {
            actual.right = insertarRecursivo(actual.right, dato);
        }
        return actual;
    }

    public void insertar(Empleado dato) {
        raiz = insertarRecursivo(raiz, dato);
    }

    // --- NUEVOS MÉTODOS PARA LA INTERFAZ GRÁFICA ---
    public String obtenerInOrdenGUI() {
        StringBuilder resultado = new StringBuilder();
        inOrdenAcumulado(raiz, resultado);
        return resultado.toString();
    }

    private void inOrdenAcumulado(Nodo nodo, StringBuilder sb) {
        if (nodo == null) return;
        inOrdenAcumulado(nodo.left, sb);
        sb.append(nodo.data.toString()).append("\n"); // Acumulamos en lugar de imprimir
        inOrdenAcumulado(nodo.right, sb);
    }
}